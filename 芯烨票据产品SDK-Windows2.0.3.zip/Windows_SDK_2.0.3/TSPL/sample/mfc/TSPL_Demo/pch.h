﻿
#ifndef PCH_H
#define PCH_H

#include "framework.h"

#endif //PCH_H
