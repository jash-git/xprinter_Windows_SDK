﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices



<Assembly: AssemblyTitle("CPCL_Demo")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("CPCL_Demo")>
<Assembly: AssemblyCopyright("Copyright ©  2023")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>


<Assembly: Guid("ba6bc105-7d9a-4589-b43c-4e888435c7eb")>



<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
