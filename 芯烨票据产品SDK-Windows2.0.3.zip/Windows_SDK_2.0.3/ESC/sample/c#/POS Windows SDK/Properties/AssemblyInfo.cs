﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

[assembly: AssemblyTitle("WinFormUSB")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("POS Printer")]
[assembly: AssemblyProduct("WinFormUSB")]
[assembly: AssemblyCopyright("Copyright © POS Printer")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("7e00ba80-224a-4eb8-bb7a-3d731c25bba0")]

[assembly: AssemblyVersion("2.1.0.1")]
[assembly: AssemblyFileVersion("2.0.1.1")]
[assembly: NeutralResourcesLanguageAttribute("zh-CN")]
