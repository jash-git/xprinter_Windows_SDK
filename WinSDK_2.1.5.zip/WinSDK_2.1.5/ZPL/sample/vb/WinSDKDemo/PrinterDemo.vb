﻿Imports System.Runtime.InteropServices

Module PrinterDemo

    Public Const POSPRINTERR As String = "printer.sdk.dll"

    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function PrinterCreator(ByRef printer As IntPtr, model As String) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function OpenPort(printer As IntPtr, setting As String) As Integer

    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ClosePort(printer As IntPtr) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ReleasePrinter(printer As IntPtr) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ReadData(printer As IntPtr, buffer As Byte(), size As Integer) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.Cdecl)>
    Public Function WriteData(printer As IntPtr, buffer As Byte(), size As Integer) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_StartFormat(printer As IntPtr) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_EndFormat(printer As IntPtr) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_Text(printer As IntPtr, xPos As Integer, yPos As Integer, fontNum As Integer, orientation As Integer, fontWidth As Integer, fontHeight As Integer, text As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_BarCode128(printer As IntPtr, xPos As Integer, yPos As Integer, orientation As Integer, moduleWidth As Integer, codeHeight As Integer, line As Char, lineAboveCode As Char, checkDigit As Char, mode As Char, text As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_QRCode(printer As IntPtr, xPos As Integer, yPos As Integer, orientation As Integer, model As Integer, dpi As Integer, eccLevel As Char, input As Char, charMode As Char, text As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_GraphicBox(printer As IntPtr, xPos As Integer, yPos As Integer, width As Integer, height As Integer, thickness As Integer, rounding As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_PrintImage(printer As IntPtr, xPos As Integer, yPos As Integer, imgName As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_DataMatrixBarcode(printer As IntPtr, xPos As Integer, yPos As Integer, orientation As Integer, codeHeight As Integer, level As Integer, columns As Integer, rows As Integer, formatId As Integer, aspectRatio As Integer, text As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_Text_Block(printer As IntPtr, xPos As Integer, yPos As Integer, fontNum As Integer, orientation As Integer, fontWidth As Integer, fontHeight As Integer, textblockWidth As Integer, textblockHeight As Integer, text As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_GetPrinterStatus(printer As IntPtr, ByRef printerStatus As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_PrintConfigurationLabel(printer As IntPtr) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ZPL_Pdf417(printer As IntPtr, xPos As Integer, yPos As Integer, orientation As Integer, moduleWidth As Integer, codeHeight As Integer, securityLevel As Integer, columns As Integer, rows As Integer, truncate As Char, text As String) As Integer
    End Function

    Private Function ParseStatus(status) As String
        If status = 0 Then
            Return "Normal!"
        ElseIf (status And &B1) > 0 Then
            Return "Head opened!"
        ElseIf (status And &B10) > 0 Then
            Return "Paper jam!"
        ElseIf (status And &B100) > 0 Then
            Return "Out of paper!"
        ElseIf (status And &B1000) > 0 Then
            Return "Out of ribbon!"
        ElseIf (status And &B10000) > 0 Then
            Return "Pause!"
        ElseIf (status And &B100000) > 0 Then
            Return "Printing!"
        ElseIf (status And &B1000000) > 0 Then
            Return "Cover opened!"
        Else
            Return "Other error!"
        End If
    End Function

    Public Sub GetStatus(printer, tb_Msg)
        Dim status As Integer
        Dim ret = ZPL_GetPrinterStatus(printer, status)
        If ret = 0 Then
            tb_Msg.Text += DateTime.Now.ToString("MM-dd HH:mm:ss") + " The printer status is " + ParseStatus(status) + vbCrLf
        Else
            tb_Msg.Text += DateTime.Now.ToString("MM-dd HH:mm:ss") + " " + "Get Error, Code is: " + ret + vbCrLf
        End If
    End Sub
    Public Sub PrintSample(printer)
        Dim xPos = 40
        ZPL_StartFormat(printer)
        ZPL_Text(printer, xPos, 50, 13, 0, 59, 53, "FROM:")
        ZPL_Text(printer, 200, 40, 3, 0, 18, 30, "Company Name")
        ZPL_Text(printer, 200, 80, 3, 0, 18, 30, "Street, City")
        ZPL_Text(printer, 200, 120, 3, 0, 18, 30, "Phone")
        ZPL_GraphicBox(printer, xPos, 170, 500, 8, 4, 0)
        ZPL_Text(printer, xPos, 200, 13, 0, 59, 53, "SHIP TO:")
        ZPL_Text(printer, 200, 190, 3, 0, 18, 30, "Company Name")
        ZPL_Text(printer, 200, 230, 3, 0, 18, 30, "Street, City")
        ZPL_Text(printer, 200, 270, 3, 0, 18, 30, "Phone")
        ZPL_GraphicBox(printer, xPos, 320, 500, 8, 4, 0)
        ZPL_Text(printer, xPos, 340, 13, 0, 59, 53, "WEIGHT:")
        ZPL_Text(printer, 200, 340, 3, 0, 18, 30, "1kg/2,2lb")
        ZPL_BarCode128(printer, 80, 410, 0, 5, 150, "Y", "N", "N", "A", "12345678")
        ZPL_EndFormat(printer)
    End Sub
    Public Sub PrintQRCode(printer)
        ZPL_StartFormat(printer)
        ZPL_QRCode(printer, 120, 5, 0, 2, 5, "Q", "0", "B", "Welcome to the world of printing!")
        ZPL_EndFormat(printer)
    End Sub
    Public Sub PrintBarCode(printer)
        ZPL_StartFormat(printer)
        ZPL_BarCode128(printer, 120, 10, 0, 3, 80, "Y", "N", "N", "A", "123456")
        ZPL_EndFormat(printer)
    End Sub
    Public Sub PrintImage(printer, path)
        ZPL_StartFormat(printer)
        ZPL_PrintImage(printer, 120, 10, path)
        ZPL_EndFormat(printer)
    End Sub

End Module
