﻿Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("WinSDKDemo")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("WinSDKDemo")>
<Assembly: AssemblyCopyright("Copyright ©  2024")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

<Assembly: Guid("97af70eb-3e29-4218-bbc6-1684a8c2ecb0")>


<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
