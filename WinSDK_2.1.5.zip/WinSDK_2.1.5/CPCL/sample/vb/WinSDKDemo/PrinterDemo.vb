﻿Imports System.Runtime.InteropServices

Module PrinterDemo

    Public Const POSPRINTERR As String = "printer.sdk.dll"

    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function PrinterCreator(ByRef printer As IntPtr, model As String) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function OpenPort(printer As IntPtr, setting As String) As Integer

    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ClosePort(printer As IntPtr) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ReleasePrinter(printer As IntPtr) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.Cdecl)>
    Public Function ReadData(printer As IntPtr, buffer As Byte(), size As Integer) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.Cdecl)>
    Public Function WriteData(printer As IntPtr, buffer As Byte(), size As Integer) As Integer
    End Function

    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddLabel(printer As IntPtr, offSet As Integer, height As Integer, qty As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_SetAlign(printer As IntPtr, align As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddText(printer As IntPtr, rotate As Integer, fontName As String, fontSize As Integer, xPos As Integer, yPos As Integer, data As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddBarCode(printer As IntPtr, rotate As Integer, type As Integer, width As Integer, ratio As Integer, height As Integer, xPos As Integer, yPos As Integer, data As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddBarCodeText(printer As IntPtr, enable As Integer, fontType As Integer, fontSize As Integer, offset As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddQRCode(printer As IntPtr, rotate As Integer, xPos As Integer, yPos As Integer, model As Integer, unitWidth As Integer, eccLevel As Integer, data As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddPDF417(printer As IntPtr, rotate As Integer, xPos As Integer, yPos As Integer, xDots As Integer, yDots As Integer, columns As Integer, eccLevel As Integer, data As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddBox(printer As IntPtr, xPos As Integer, yPos As Integer, endXPos As Integer, endYPos As Integer, thickness As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddLine(printer As IntPtr, xPos As Integer, yPos As Integer, endXPos As Integer, endYPos As Integer, thickness As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddImage(printer As IntPtr, rotate As Integer, xPos As Integer, yPos As Integer, filePath As String) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_SetTextUnderline(printer As IntPtr, bunderlineold As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_Print(printer As IntPtr) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_GetPrinterStatus(printer As IntPtr, ByRef printerStatus As Integer) As Integer
    End Function
    <DllImport(POSPRINTERR, CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.Cdecl)>
    Public Function CPCL_AddInverseLine(printer As IntPtr, xPos As Integer, yPos As Integer, xEnd As Integer, yEnd As Integer, width As Integer) As Integer
    End Function

    Private Function ParseStatus(status) As String
        If status = 0 Then
            Return "Normal!"
        ElseIf (status And &B1) > 0 Then
            Return "Head opened!"
        ElseIf (status And &B10) > 0 Then
            Return "Paper jam!"
        ElseIf (status And &B100) > 0 Then
            Return "Out of paper!"
        ElseIf (status And &B1000) > 0 Then
            Return "Out of ribbon!"
        ElseIf (status And &B10000) > 0 Then
            Return "Pause!"
        ElseIf (status And &B100000) > 0 Then
            Return "Printing!"
        ElseIf (status And &B1000000) > 0 Then
            Return "Cover opened!"
        Else
            Return "Other error!"
        End If
    End Function

    Public Sub GetStatus(printer, tb_Msg)
        Dim status As Integer
        Dim ret = CPCL_GetPrinterStatus(printer, status)
        If ret = 0 Then
            tb_Msg.Text += DateTime.Now.ToString("MM-dd HH:mm:ss") + " The printer status is " + ParseStatus(status) + vbCrLf
        Else
            tb_Msg.Text += DateTime.Now.ToString("MM-dd HH:mm:ss") + " " + "Get Error, Code is: " + ret + vbCrLf
        End If
    End Sub
    Public Sub PrintSample(printer)
        CPCL_AddLabel(printer, 0, 400, 1)
        CPCL_AddBox(printer, 10, 10, 510, 280, 5)
        CPCL_AddLine(printer, 10, 180, 510, 180, 4)
        CPCL_AddQRCode(printer, 0, 20, 20, 2, 6, 3, "QR CODE ABC123")
        CPCL_SetAlign(printer, 0)
        CPCL_AddText(printer, 0, "0", 0, 300, 20, "REVERSE")
        CPCL_AddInverseLine(printer, 290, 20, 390, 20, 24)
        CPCL_AddText(printer, 0, "0", 0, 170, 20, "FONT0")
        CPCL_AddText(printer, 0, "1", 0, 170, 60, "FONT1")
        CPCL_AddText(printer, 0, "2", 0, 170, 80, "FONT2")
        CPCL_AddText(printer, 0, "3", 0, 170, 120, "FONT3")
        CPCL_AddBarCode(printer, 0, 20, 1, 1, 50, 270, 80, "123456789")
        CPCL_AddText(printer, 0, "0", 0, 20, 210, "Hello World!")
        CPCL_AddLine(printer, 200, 200, 450, 200, 50)
        CPCL_Print(printer)
    End Sub
    Public Sub PrintQRCode(printer)
        CPCL_AddLabel(printer, 0, 400, 1)
        CPCL_AddQRCode(printer, 0, 20, 20, 2, 8, 3, "QR CODE ABC123")
        CPCL_Print(printer)
    End Sub
    Public Sub PrintBarCode(printer)
        CPCL_AddLabel(printer, 0, 800, 1)
        CPCL_AddBarCodeText(printer, 1, 7, 0, 0)
        CPCL_AddText(printer, 0, "0", 0, 0, 0, "Code 128")
        CPCL_AddBarCode(printer, 0, 20, 1, 1, 50, 0, 30, "123456789")
        CPCL_AddText(printer, 0, "0", 0, 0, 120, "UPC-E")
        CPCL_AddBarCode(printer, 0, 3, 1, 1, 50, 0, 150, "223456")
        CPCL_AddText(printer, 0, "0", 0, 0, 240, "EAN/JAN-13")
        CPCL_AddBarCode(printer, 0, 6, 1, 1, 50, 0, 270, "323456791234")
        CPCL_AddText(printer, 0, "0", 0, 0, 360, "Code 39")
        CPCL_AddBarCode(printer, 0, 12, 1, 1, 50, 0, 390, "72233445")
        CPCL_AddText(printer, 0, "0", 0, 250, 0, "UPC-A")
        CPCL_AddBarCode(printer, 0, 0, 1, 1, 50, 250, 30, "423456789012")
        CPCL_AddText(printer, 0, "0", 0, 250, 120, "EAN/JAN-8")
        CPCL_AddBarCode(printer, 0, 9, 1, 1, 50, 250, 150, "52233445")
        CPCL_AddText(printer, 0, "0", 0, 300, 360, "CODABAR")
        CPCL_AddBarCode(printer, 1, 22, 1, 1, 50, 300, 540, "A67859B")
        CPCL_AddText(printer, 0, "0", 0, 0, 480, "Code 93/Ext.93")
        CPCL_AddBarCode(printer, 0, 16, 1, 1, 50, 0, 510, "823456789")
        CPCL_AddBarCodeText(printer, 0, 7, 0, 0)
        CPCL_Print(printer)
    End Sub
    Public Sub PrintImage(printer, path)
        CPCL_AddLabel(printer, 0, 600, 1)
        CPCL_SetAlign(printer, 0)
        CPCL_AddImage(printer, 0, 40, 0, path)
        CPCL_Print(printer)
    End Sub

End Module
