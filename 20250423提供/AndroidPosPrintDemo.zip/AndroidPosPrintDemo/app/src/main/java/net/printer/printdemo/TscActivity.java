package net.printer.printdemo;

import static net.posprinter.utils.StringUtils.strTobytes;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.oned.UPCAWriter;

import net.posprinter.posprinterface.ProcessData;
import net.posprinter.posprinterface.SerialNumCallback;
import net.posprinter.posprinterface.TaskCallback;
import net.posprinter.utils.BitmapProcess;
import net.posprinter.utils.BitmapToByteData;
import net.posprinter.utils.DataForSendToPrinterTSC;
import net.posprinter.utils.PosPrinterDev;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TscActivity extends AppCompatActivity implements View.OnClickListener{

    private Button content,text,barcode,qrcode,bitmap,status,btn_serial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tsc);
        initView();
    }

    private void initView(){
        content = findViewById(R.id.bt_tsp);
        text = findViewById(R.id.bt_text);
        barcode =findViewById(R.id.bt_barcode);
        qrcode = findViewById(R.id.bt_qr);
        bitmap = findViewById(R.id.bt_bitmap);
        status=findViewById(R.id.bt_status);
        content.setOnClickListener(this);
        text.setOnClickListener(this);
        barcode.setOnClickListener(this);
        qrcode.setOnClickListener(this);
        bitmap.setOnClickListener(this);
        status.setOnClickListener(this);
        btn_serial=findViewById(R.id.bt_serial);
        btn_serial.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.bt_tsp:
                printContent();
                break;
            case R.id.bt_text:
                printText();
                break;
            case   R.id.bt_barcode:
                printBarcode();
                break;
            case R.id.bt_qr:
                printQR();
                break;
            case R.id.bt_bitmap:
                printbitmap();
                break;
            case R.id.bt_status:
                GetStatus();
                break;
            case R.id.bt_serial:
                SetSerialNum();
                break;
        }
    }
    public void SetSerialNum(){
//         MainActivity.myBinder.SetSerialNum("abcd123456789");
        MainActivity.myBinder.SetPrinterMonitor(false);
        MainActivity.myBinder.StopMonitorPrinter();
         MainActivity.myBinder.GetSerialNum(new SerialNumCallback() {
            @Override
            public void onSuccess(String serialNum) {
                Log.e("onSuccess getserialnum:",serialNum);
                Toast.makeText(getApplicationContext(),serialNum,Toast.LENGTH_SHORT).show();
                MainActivity.myBinder.SetPrinterMonitor(true);
                MainActivity.myBinder.StartMonitorPrinter();
            }

            @Override
            public void onFailure(String error) {
                Log.e("onFailure getserialnum:",error);
            }
        });
//         MainActivity.myBinder.SetBluetoothName("ble04");
    }
    //Get printer status
    private void GetStatus(){
        if (MainActivity.ISCONNECT){
            Log.e("",MainActivity.myBinder.GetPrinterStatus().toString());
            Toast.makeText(getApplicationContext(),MainActivity.myBinder.GetPrinterStatus().toString(),Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(getApplicationContext(),getString(R.string.connect_first),Toast.LENGTH_SHORT).show();
        }
    }

    //打印文本
    private void printContent(){
        if (MainActivity.ISCONNECT){

            MainActivity.myBinder.WriteSendData(new TaskCallback() {
                @Override
                public void OnSucceed() {
                    Toast.makeText(getApplicationContext(),getString(R.string.send_success),Toast.LENGTH_SHORT).show();
                }

                @Override
                public void OnFailed() {
                    Toast.makeText(getApplicationContext(),getString(R.string.send_failed),Toast.LENGTH_SHORT).show();

                }
            }, new ProcessData() {
                @Override
                public List<byte[]> processDataBeforeSend() {
                    List<byte[]> list = new ArrayList<>();
                    //设置标签纸大小
                    list.add(DataForSendToPrinterTSC.sizeBymm(50,30));
                    //设置间隙
                    list.add(DataForSendToPrinterTSC.gapBymm(2,0));
                    //清除缓存
                    list.add(DataForSendToPrinterTSC.cls());
                    //设置方向
                    list.add(DataForSendToPrinterTSC.direction(0));
                    //线条
                    list.add(DataForSendToPrinterTSC.bar(10,10,200,3));
                    //条码
                    list.add(DataForSendToPrinterTSC.barCode(10,45,"128",100,1,0,2,2,"abcdef12345"));
                    //文本,简体中文是TSS24.BF2,可参考编程手册中字体的代号
                    list.add(DataForSendToPrinterTSC.text(220,10,"TSS24.BF2",0,1,1,"这是测试文本"));
                    //打印
                    list.add(DataForSendToPrinterTSC.print(1));

                    return list;
                }
            });

        }else {
            Toast.makeText(getApplicationContext(),getString(R.string.connect_first),Toast.LENGTH_SHORT).show();
        }
    }

    //print label text
    private void printText(){
        if (MainActivity.ISCONNECT){

            MainActivity.myBinder.WriteSendData(new TaskCallback() {
                @Override
                public void OnSucceed() {
                    Toast.makeText(getApplicationContext(),getString(R.string.send_success),Toast.LENGTH_SHORT).show();
                }
                @Override
                public void OnFailed() {
                    Toast.makeText(getApplicationContext(),getString(R.string.send_failed),Toast.LENGTH_SHORT).show();
                }
            }, new ProcessData() {
                @Override
                public List<byte[]> processDataBeforeSend() {
                    List<byte[]> list = new ArrayList<>();
                    //set label size
                    list.add(DataForSendToPrinterTSC.sizeBymm(75,40));
                    //set gap
                    //list.add(DataForSendToPrinterTSC.gapBymm(2,0));
                    //set black line
                    list.add(DataForSendToPrinterTSC.blineBymm(3,0));
                    //clear buffer
                    list.add(DataForSendToPrinterTSC.cls());
                    //direction
                    list.add(DataForSendToPrinterTSC.direction(0));
                    //line
//                    list.add(DataForSendToPrinterTSC.bar(10,10,200,3));
                    //text
                    //korean
                    list.add(DataForSendToPrinterTSC.textKorean(50,10,"K",90,1,1,"감열식 프린터"));
                    //english
                    list.add(DataForSendToPrinterTSC.text(100,10,"TSS24.BF2",90,1,1,"abcasdjknf"));
                    //code128
                    list.add(DataForSendToPrinterTSC.barCode(300,10,"128",100,1,90,2,2,"abcdef12345"));
                    list.add(DataForSendToPrinterTSC.textChinese(100,30,"TSS24.BF2",0,1,1,"标签打印机標籤印表機"));
                    //print
                    list.add(DataForSendToPrinterTSC.print(1));
                    return list;
                }
            });
        }else {
            Toast.makeText(getApplicationContext(),getString(R.string.connect_first),Toast.LENGTH_SHORT).show();
        }

    }

    private void printBarcode(){
        if (MainActivity.ISCONNECT){

            MainActivity.myBinder.WriteSendData(new TaskCallback() {
                @Override
                public void OnSucceed() {
                    Toast.makeText(getApplicationContext(),getString(R.string.send_success),Toast.LENGTH_SHORT).show();
                }

                @Override
                public void OnFailed() {
                    Toast.makeText(getApplicationContext(),getString(R.string.send_failed),Toast.LENGTH_SHORT).show();

                }
            }, new ProcessData() {
                @Override
                public List<byte[]> processDataBeforeSend() {
                    List<byte[]> list = new ArrayList<>();
                    //设置标签纸大小
                    list.add(DataForSendToPrinterTSC.sizeBymm(50,30));
                    //设置间隙
                    list.add(DataForSendToPrinterTSC.gapBymm(2,0));
                    //清除缓存
                    list.add(DataForSendToPrinterTSC.cls());
                    //设置方向
                    list.add(DataForSendToPrinterTSC.direction(0));
                    //线条
//                    list.add(DataForSendToPrinterTSC.bar(10,10,200,3));
                    //条码
                    list.add(DataForSendToPrinterTSC.barCode(10,15,"128",100,1,0,2,2,"abcdef12345"));
                    //文本
//                    list.add(DataForSendToPrinterTSC.text(10,30,"1",0,1,1,"abcasdjknf"));
                    //打印
                    list.add(DataForSendToPrinterTSC.print(1));

                    return list;
                }
            });

        }else {
            Toast.makeText(getApplicationContext(),getString(R.string.connect_first),Toast.LENGTH_SHORT).show();
        }
    }

    private void printQR(){
        if (MainActivity.ISCONNECT){

            MainActivity.myBinder.WriteSendData(new TaskCallback() {
                @Override
                public void OnSucceed() {
                    Toast.makeText(getApplicationContext(),getString(R.string.send_success),Toast.LENGTH_SHORT).show();
                }

                @Override
                public void OnFailed() {
                    Toast.makeText(getApplicationContext(),getString(R.string.send_failed),Toast.LENGTH_SHORT).show();

                }
            }, new ProcessData() {
                @Override
                public List<byte[]> processDataBeforeSend() {
                    List<byte[]> list = new ArrayList<>();
                    //设置标签纸大小
                    list.add(DataForSendToPrinterTSC.sizeBymm(50,30));
                    //设置间隙
                    list.add(DataForSendToPrinterTSC.gapBymm(2,0));
                    //清除缓存
                    list.add(DataForSendToPrinterTSC.cls());
                    //设置方向
                    list.add(DataForSendToPrinterTSC.direction(0));
                    //具体参数值请参看编程手册
                    list.add(DataForSendToPrinterTSC.qrCode(10,20,"M",3,"A",0,"M1","S3","123456789"));
                    //打印
                    list.add(DataForSendToPrinterTSC.print(1));

                    return list;
                }
            });

        }else {
            Toast.makeText(getApplicationContext(),getString(R.string.connect_first),Toast.LENGTH_SHORT).show();
        }
    }
    Bitmap adjustPhotoRotation(Bitmap bm, final int orientationDegree) {
        Matrix m = new Matrix();
        m.setRotate(orientationDegree, (float) bm.getWidth() / 2, (float) bm.getHeight() / 2);
        float targetX, targetY;
        if (orientationDegree == 90) {
            targetX = bm.getHeight();
            targetY = 0;
        } else {
            targetX = bm.getHeight();
            targetY = bm.getWidth();
        }
        final float[] values = new float[9];
        m.getValues(values);
        float x1 = values[Matrix.MTRANS_X];
        float y1 = values[Matrix.MTRANS_Y];
        m.postTranslate(targetX - x1, targetY - y1);
        Bitmap bm1 = Bitmap.createBitmap(bm.getHeight(), bm.getWidth(), Bitmap.Config.ARGB_8888);
        Paint paint = new Paint();
        Canvas canvas = new Canvas(bm1);
        canvas.drawBitmap(bm, m, paint);
        return bm1;
    }
    public static Bitmap createBlankImage(int width, int height) {
        Bitmap blankImage = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(blankImage);
        canvas.drawColor(Color.WHITE);
        return blankImage;
    }
    // Generate barcode bitmap (implement this method)
    public static Bitmap generateBarcodeBitmap(String text, int width, int height) {
        try {
            BitMatrix matrix = new MultiFormatWriter().encode(text, BarcodeFormat.CODE_128, width, height);
            int[] pixels = new int[width * height];

            for (int j = 0; j < height; j++) {
                for (int i = 0; i < width; i++) {
                    if (matrix.get(i, j)) {
                        pixels[j * width + i] = Color.BLACK;
                    }
                }
            }

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public void saveBitmap(Bitmap bitmap) {
        Uri saveUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues());
        if (TextUtils.isEmpty(saveUri.toString())) {
            Toast.makeText(this, "Saved successfully", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            OutputStream outputStream = getContentResolver().openOutputStream(saveUri);
            if (bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)) {
                Toast.makeText(this, "Saved successfully！", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Save failed！", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void printbitmap(){
        int labelWidth=75;//mm
        int labelHeight=200;//mm
        // Load your original image
        Bitmap originalBitmap = createBlankImage(labelHeight*8,labelWidth*8);
        // Create a canvas to draw on the original image
        Canvas canvas = new Canvas(originalBitmap);
        // Define text properties
        Paint textPaint = new Paint();
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(24f);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        // Draw text at specified coordinates
        canvas.drawText("인쇄기인쇄기", 50f, 100f, textPaint);
        // Generate barcode bitmap (replace with your actual barcode data)
        Bitmap barcodeBitmap = generateBarcodeBitmap("1234567890",300,100);
        // Draw barcode at specified coordinates
        canvas.drawBitmap(barcodeBitmap, 200f, 200f, null);
        // Save the merged image (you can customize this part)
        saveBitmap(originalBitmap);
//        Bitmap bitmap1 =  BitmapProcess.compressBmpByYourWidth
//                (BitmapFactory.decodeResource(getResources(), R.drawable.test),labelHeight*8);
        final Bitmap bitmap2=adjustPhotoRotation(originalBitmap,90);
//        int xCoordinate=(labelWidth*8-bitmap2.getWidth())/2;//dots
//        int yCoordinate=10;//dots
        int xCoordinate=0;//dots
        int yCoordinate=0;//dots
        MainActivity.myBinder.WriteSendData(new TaskCallback() {
            @Override
            public void OnSucceed() {
                Toast.makeText(getApplicationContext(),getString(R.string.send_success),Toast.LENGTH_SHORT).show();

            }

            @Override
            public void OnFailed() {
                Toast.makeText(getApplicationContext(),getString(R.string.send_failed),Toast.LENGTH_SHORT).show();

            }
        }, new ProcessData() {
            @Override
            public List<byte[]> processDataBeforeSend() {
                List<byte[]> list = new ArrayList<>();
                //set label size
                list.add(DataForSendToPrinterTSC.sizeBymm(labelWidth,labelHeight));
                //set label gap
                //list.add(DataForSendToPrinterTSC.gapBymm(2,0));
                //set bline
                list.add(DataForSendToPrinterTSC.blineBymm(3,0));
                //clear buffer
                list.add(DataForSendToPrinterTSC.cls());
                //set print direction 0 or 1
                list.add(DataForSendToPrinterTSC.direction(0));
                //print image
                list.add(DataForSendToPrinterTSC.bitmap(xCoordinate,yCoordinate,0,bitmap2, BitmapToByteData.BmpType.Threshold));
                list.add(DataForSendToPrinterTSC.print(1));

//                //2023.5.18 ding 测试同一张标签pdf使用两次发送
//                //设置标签纸大小
//                list.add(DataForSendToPrinterTSC.sizeBymm(80,100));
//                //设置间隙
//                list.add(DataForSendToPrinterTSC.gapBymm(0,0));
//                //清除缓存
//                list.add(DataForSendToPrinterTSC.cls());
//                list.add(DataForSendToPrinterTSC.bitmap(10,10,0,bitmap1, BitmapToByteData.BmpType.Threshold));
//                list.add(DataForSendToPrinterTSC.print(1));
//
//                list.add(DataForSendToPrinterTSC.sizeBymm(80,100));
//                list.add(DataForSendToPrinterTSC.gapBymm(0,0));
//                //清除缓存
//                list.add(DataForSendToPrinterTSC.cls());
//                list.add(DataForSendToPrinterTSC.bitmap(10,400,0,bitmap1, BitmapToByteData.BmpType.Threshold));
//                list.add(DataForSendToPrinterTSC.print(1));
                return list;
            }
        });
    }


}
